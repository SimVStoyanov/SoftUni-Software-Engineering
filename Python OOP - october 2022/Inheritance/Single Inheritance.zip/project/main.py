from project.animal import Animal
from project.dog import Dog

a = Animal()
d = Dog()

print(d.eat())
print(a.eat())

print(d.bark())
