from project.sports_car import SportsCar

sc = SportsCar()
print(sc.move())
print(sc.drive())
print(sc.race())
